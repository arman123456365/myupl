<?php
/**
 * Bookable Query
 *
 * @package  BKAP/bookable-query
 */

/**
 * Bookings and Appointment Plugin for WooCommerce
 *
 * Class containing helpers to query data.
 *
 * @author   Tyche Softwares
 * @category Classes
 */
class BKAP_Bookable_Query {

	/**
	 * Posttype for bookable
	 *
	 * @var string
	 */
	private static $posttype = 'product';

	/**
	 * Number of bookable to show
	 *
	 * @var integer
	 */
	private static $numberpost = 10;

	/**
	 * Meta query to filter bookable
	 *
	 * @var array
	 */
	private static $meta_query = array(
		'relation' => 'AND',
		array(
			'key'     => '_bkap_enable_booking',
			'value'   => 'on',
			'compare' => '=',
		),
	);

	/**
	 * Valid post status for bookable
	 *
	 * @var array
	 */
	private static $bookable_status = array(
		'publish',
		'pending',
		'draft',
		'auto-draft',
		'future',
		'private',
		'inherit',
	);

	/**
	 * Get query args
	 *
	 * @param array $args query arguments.
	 * @return array
	 */
	public static function get_query_args( $args ) {

		$filter   = isset( $args['filter'] ) ? $args['filter'] : '';
		$filter   = bkap_common::get_attribute_value( $filter );
		$tax_args = self::get_tax_query_args( $args );

		$query_args = array(
			'post_type'   => self::$posttype,
			'status'      => self::$bookable_status,
			'numberposts' => ! empty( $args['numberposts'] ) ? $args['numberposts'] : self::$numberpost,
		);

		if ( defined( 'ICL_SITEPRESS_VERSION' ) ) {
			$current_language   = apply_filters( 'wpml_current_language', NULL );
			$query_args['lang'] = $current_language;
		}

		$query_args['suppress_filters'] = 0;
		$query_args['meta_query']       = self::get_meta_query_args( $args ); // phpcs:ignore

		if ( ! empty( $tax_args ) ) {
			$query_args['tax_query'] = $tax_args; // phpcs:ignore
		}

		if ( 'products' === $filter && ! empty( $args['products'] ) ) {
			$products              = bkap_common::get_attribute_value( $args['products'] );
			$product_ids           = is_array( $products ) ? explode( ',', $products ) : $products;
			$query_args['include'] = $product_ids;
		}

		return $query_args;
	}

	/**
	 * Get meta query args
	 *
	 * @param  array $args arguments.
	 * @return array
	 */
	public static function get_meta_query_args( $args ) {
		$filter     = isset( $args['filter'] ) ? $args['filter'] : '';
		$filter     = bkap_common::get_attribute_value( $filter );
		$meta_query = self::$meta_query;

		// Get bookable by type (day/time).
		if ( 'type' === $filter && ! empty( $args['type'] ) ) {
				$type          = $args['type'];
				$bookable_type = $args[ $type . 'Type' ];
				$meta_query[]  = array(
					'key'   => '_bkap_booking_type',
					'value' => $bookable_type,
				);
		}

		// Get bookable products by resources.
		if ( 'resources' === $filter && ! empty( $args['resources'] ) ) {
			$resources = explode( ',', bkap_common::get_attribute_value( $args['resources'] ) );
			// Add each resource to meta query.
			foreach ( $resources as $id ) {
				$resource_args[] = array(
					'key'     => '_bkap_product_resources',
					'value'   => $id,
					'compare' => 'LIKE',
				);
			}

			$meta_query[] = array_merge( array( 'relation' => 'OR' ), $resource_args );
		}

		return $meta_query;
	}

	/**
	 * Get taxonomy args
	 *
	 * @param  array $args arguments.
	 * @return array
	 */
	public static function get_tax_query_args( $args ) {

		$filter    = isset( $args['filter'] ) ? $args['filter'] : '';
		$filter    = bkap_common::get_attribute_value( $filter );
		$tax_query = array();

		// Get bookables based on categories.
		if ( 'categories' === $filter && ! empty( $args['categories'] ) ) {
			$categories = bkap_common::get_attribute_value( $args['categories'] );
			$tax_query  = array(
				array(
					'taxonomy' => 'product_cat',
					'terms'    => $categories,
				),
			);
		}

		return $tax_query;
	}

	/**
	 * Get bookable data
	 *
	 * @param  array $args arguments.
	 * @return array|boolean
	 */
	public static function get_data( $args ) {
		return get_posts( self::get_query_args( $args ) );
	}

	/**
	 * Get bookable products with events rrule for calender.
	 *
	 * @param  array $args display args.
	 * @return array
	 */
	public static function get_events( $args ) {

		$show_times             = isset( $args['showTimes'] ) ? $args['showTimes'] : false;
		$sort_single_day_events = isset( $args['sortingSingleEvents'] ) ? $args['sortingSingleEvents'] : false;
		$events                 = array();
		$bookables              = self::get_data( $args );
		$show_times             = rest_sanitize_boolean( $show_times );
		$sort_single_day_events = rest_sanitize_boolean( $sort_single_day_events );
		$current_time           = current_time( 'timestamp' ); // WordPress Time.
		$current_date           = gmdate( 'Y-m-d', $current_time );
		$phpversion             = version_compare( phpversion(), '5.3', '>' );
		$today                  = gmdate( 'Y-m-d H:i', $current_time );
		$date1                  = new DateTime( $today );
		$global_settings        = bkap_global_setting();
		$global_holidays        = explode( ',', $global_settings->booking_global_holidays );
		$timezone               = bkap_timezone_check( $global_settings );
		$last_event_date        = array();

		foreach ( $bookables as $bookable ) {

			// Initial settings.
			$booking_type     = $bookable->_bkap_booking_type;
			$custom_range     = $bookable->_bkap_custom_ranges;
			$holidays         = is_array( $bookable->_bkap_product_holidays ) ? array_keys( $bookable->_bkap_product_holidays ) : array();
			$holidays         = array_merge( $holidays, $global_holidays );
			$product_id       = $bookable->ID;
			$_product         = wc_get_product( $product_id );
			$product_type     = $_product->get_type();
			$resources        = bkap_common::get_bookable_resources( $product_id );
			$price            = $_product->get_price();
			$booking_settings = $bookable->woocommerce_booking_settings;

			// Calculation for setting min and max date for product.
			if ( ! empty( $custom_range ) ) {
				$min_max_dates      = bkap_minmax_date_custom_range( $bookable->ID, $custom_range );
				$min_date           = $min_max_dates[0];
				$end_date           = $min_max_dates[1];
				$custom_range_dates = $min_max_dates[2];
			} else {
				$min_date = bkap_common::bkap_min_date_based_on_AdvanceBookingPeriod( $bookable->ID, $current_time );
				$end_date = calback_bkap_max_date( $current_date, $bookable->_bkap_max_bookable_days, $bookable->woocommerce_booking_settings );/* '2020-07-30'; */
				$end_date = gmdate( 'Y-m-d H:i:s', strtotime( $end_date . '23.59' ) );
			}

			$last_event_date[] = $end_date;
			$start             = gmdate( 'Y-m-d', strtotime( $min_date ) );
			$frequency         = 'daily';
			$interval          = 1;
			$allday            = ( $show_times ? false : true );

			// Structure data.
			$bookable_item = array(
				'id'            => $bookable->ID,
				'title'         => $bookable->post_title,
				'url'           => esc_url( get_permalink( $bookable ) ),
				'allDay'        => $allday,
				'rrule'         => array(
					'dtstart'  => $start, // Booking Start.
					'freq'     => $frequency, // Daily/Weekly/hourly etc.
					'interval' => $interval, // Booking interval day/hours/min etc.
					'until'    => $end_date,
				),
				'extendedProps' => array(
					'productType'   => $product_type,
					'bookingType'   => $booking_type,
					'view'          => ( isset( $args['view'] ) ? $args['view'] : '' ),
					'greyOutBooked' => ( isset( $args['greyOutBooked'] ) ? $args['greyOutBooked'] : '' ),
					'showQuantity'  => ( isset( $args['showQuantity'] ) ? $args['showQuantity'] : '' ),
					'holidays'      => $holidays,
					'showTime'      => $show_times,
					'price'         => $price,
					'start'         => $start,
					'end'           => $end_date,
				),
			);

			if ( isset( $custom_range_dates ) ) {
				$bookable_item['extendedProps']['custom_range_dates'] = $custom_range_dates;
			}

			// Sort single day events.
			$bookable_item['extendedProps']['sort'] = in_array( $booking_type, array( 'only_day', 'multidates' ), true ) ? 0 : 1;

			// Set product type as variable when show time is false to display select options.
			if ( ! $show_times && in_array( $booking_type, array( 'duration_time', 'date_time', 'multidates_fixedtime' ), true ) ) {
				$bookable_item['extendedProps']['product_type'] = 'variable';
			}

			// Set all day for single day.
			if ( in_array( $booking_type, array( 'only_day', 'multiple_days', 'multidates' ), true ) ) {
				$bookable_item['allDay'] = true;
			}

			// Weekdays.
			$recurring_weekdays = $bookable->_bkap_recurring_weekdays;

			if ( ! empty( $recurring_weekdays ) ) {
				$weekdays_keys                       = array( 'su', 'mo', 'tu', 'we', 'th', 'fr', 'sa' );
				$weekdays_values                     = array_values( $recurring_weekdays );
				$weekdays_data                       = array_combine( $weekdays_keys, $weekdays_values );
				$weekdays                            = array_keys( array_filter( $weekdays_data ) );
				$bookable_item['rrule']['byweekday'] = $weekdays;
			}

			// check for Manage Availability Time.
			$mta_check = ( isset( $booking_settings['bkap_manage_time_availability'] ) && ! empty( $booking_settings['bkap_manage_time_availability'] ) );

			// Set duration based rules.
			if ( 'duration_time' === $booking_type && $show_times ) {
				$hourly            = '00';
				$minutely          = '00';
				$duration_settings = $bookable->_bkap_duration_settings;

				if ( isset( $duration_settings ) && is_array( $duration_settings ) ) {

					$frequency = '';
					$into      = 0;
					$hourly    = 0;

					if ( isset( $duration_settings['duration_type'] ) ) {

						switch ( $duration_settings['duration_type'] ) {
							case 'mins':
									$frequency = 'minutely';
									$into      = 60;
									$minutely  = $duration_settings['duration'];
								break;
							case 'hours':
									$frequency = 'hourly';
									$into      = 3600;
									$hourly    = $duration_settings['duration'];
								break;
						}
					}

					$first         = ( isset( $duration_settings['first_duration'] ) && '' !== $duration_settings['first_duration'] ) ? $duration_settings['first_duration'] : '00:10';
					$first_explode = explode( ':', $first );
					$last          = ( isset( $duration_settings['end_duration'] ) && '' !== $duration_settings['end_duration'] ) ? $duration_settings['end_duration'] : '23:59';
					$start         = gmdate( "Y-m-d\T{$first}" );
					$interval      = ( isset( $duration_settings['duration'] ) && '' !== $duration_settings['duration'] ) ? $duration_settings['duration'] : '';

					// Calculate number of hours and mins for end time.
					$start_date                        = new DateTime( $first );
					$end_date                          = new DateTime( $last );
					$int                               = $start_date->diff( $end_date );
					$hours                             = $int->format( '%H' );
					$minutes                           = $int->format( '%i' );
					$minutes                           = ( $minutes < 10 ) ? '0' . $minutes : $minutes;
					$bookable_item['rrule']['dtstart'] = gmdate( 'Y-m-d H:i:s', ( $current_time + ( $bookable->_bkap_abp * 3600 ) ) );

					// Need some help in setting frequency and interval so look at it later.
					// $bookable_item['rrule']['freq']      = 'RRule.DAILY';
					// $bookable_item['rrule']['interval']  = 5;

					$bookable_item['rrule']['byhour']   = array( $first_explode[0] );
					$bookable_item['rrule']['byminute'] = array( $first_explode[1] );
					$bookable_item['duration']          = $hours . ':' . $minutes;

					if ( $mta_check ) {
						$manage_time_availability_data = $booking_settings['bkap_manage_time_availability'];
						usort( $manage_time_availability_data, 'bkap_sort_date_time_ranges_by_priority' );
						$bookable_item['extendedProps']['manage_time_availability'] = $manage_time_availability_data;
					}
				}
			}

			// Set slots.
			$push          = true;
			$resource_push = false;
			if ( in_array( $booking_type, array( 'date_time', 'multidates_fixedtime' ), true ) && $show_times && ! empty( $bookable->_bkap_time_settings ) ) {
				$time_settings      = $bookable->_bkap_time_settings;
				$time_bookable_item = $bookable_item;
				$i                  = 0;
				$newtimedata        = array();
				foreach ( $time_settings as $week => $time_setting ) {
					$weekday_cal = true;
					if ( strpos( $week, 'weekday' ) === false ) {
						$weekday_cal = false;
					}

					if ( ! $weekday_cal && strtotime( $week ) < strtotime( $min_date ) ) {
						continue;
					}

					$w = $weekdays_keys[ substr( $week, -1 ) ];
					foreach ( $time_setting as $key => $time_data ) {

						$push       = false;
						$open_ended = false;
						$from       = $time_data['from_slot_hrs'] . ':' . $time_data['from_slot_min'];
						$to         = $time_data['to_slot_hrs'] . ':' . $time_data['to_slot_min'];
						if ( '0:00' == $to ) {
							$open_ended = true;
							$to         = '23:59';
						}
						$newtimedata[ $i ]['extendedProps']['actual_timeslot_value'] = $from . ' - ' . $to;

						$booking_time = apply_filters( 'bkap_change_date_comparison_for_abp', $current_date . $from, $min_date, $from, $to, $product_id, $bookable->woocommerce_booking_settings );
						$date2        = new DateTime( $booking_time );
						$include      = bkap_dates_compare( $date1, $date2, $bookable->_bkap_abp, $phpversion );
						$start_date   = new DateTime( $from );
						$end_date     = new DateTime( $to );
						$interval     = $start_date->diff( $end_date );
						$hours        = $interval->format( '%H' );
						$minutes      = $interval->format( '%i' );
						$minutes      = ( $minutes < 10 ) ? '0' . $minutes : $minutes;

						$newtimedata[ $i ] = $time_bookable_item;
						if ( $weekday_cal ) {
							if ( ! $include ) {
								$newtimedata[ $i ]['rrule']['dtstart'] = gmdate( 'Y-m-d H:i:s', ( $current_time + ( $bookable->_bkap_abp * 3600 ) ) );
							}
							$newtimedata[ $i ]['rrule']['byweekday'] = array( $w );
							$newtimedata[ $i ]['rrule']['byhour']    = array( $time_data['from_slot_hrs'] );/* $hours_from; */
							$newtimedata[ $i ]['rrule']['byminute']  = array( $time_data['from_slot_min'] );/* $hours_from; */
						} else {
							unset( $newtimedata[ $i ]['rrule'] );
							$newtimedata[ $i ]['start'] = gmdate( 'Y-m-d H:i:s', strtotime( $week . ' ' . $from ) );
							if ( ! $open_ended ) {
								$newtimedata[ $i ]['end'] = gmdate( 'Y-m-d H:i:s', strtotime( $week . ' ' . $to ) );
							}
						}

						if ( ! $open_ended ) {
							$newtimedata[ $i ]['duration'] = $hours . ':' . $minutes;
						}

						if ( $timezone && ! is_admin() ) {
							$store_timezone_string = bkap_booking_get_timezone_string();
							$offset                = bkap_get_offset_from_date( strtotime( $current_date ), $store_timezone_string );
							date_default_timezone_set( $store_timezone_string ); // phpcs:ignore

							$fromtime = strtotime( $from );
							$from     = gmdate( 'H:i', $offset + $fromtime );
							$from_exp = explode( ':', $from );
							if ( $weekday_cal ) {
								$newtimedata[ $i ]['rrule']['byhour']   = array( $from_exp[0] );
								$newtimedata[ $i ]['rrule']['byminute'] = array( $from_exp[1] );
							} else {
								$newtimedata[ $i ]['start'] = gmdate( 'Y-m-d H:i:s', $offset + strtotime( $newtimedata[ $i ]['start'] ) );
								if ( ! $open_ended ) {
									$newtimedata[ $i ]['end'] = gmdate( 'Y-m-d H:i:s', $offset + strtotime( $newtimedata[ $i ]['end'] ) );
								}
							}

							if ( ! $open_ended ) {
								$totime = strtotime( $to );
								$to     = gmdate( 'H:i', $offset + $totime );
							}
							date_default_timezone_set( 'UTC' ); // phpcs:ignore
						}

						$newtimedata[ $i ]['extendedProps']['timeslot_value'] = ( $open_ended ) ? $from : $from . ' - ' . $to;

						if ( $mta_check ) {
							$manage_time_availability_data = $booking_settings['bkap_manage_time_availability'];
							usort( $manage_time_availability_data, 'bkap_sort_date_time_ranges_by_priority' );
							$newtimedata[ $i ]['extendedProps']['manage_time_availability'] = $manage_time_availability_data;
						}
						if ( ! $resources ) {
							array_push( $events, $newtimedata[ $i ] );
						}

						$i++;
					}
				}

				$bookable_item = $newtimedata;
			}

			if ( isset( $resources ) && is_array( $resources ) && count( $resources ) > 0 ) { // saparating when product having resource.

				$_resources      = ( isset( $args['resources'] ) && is_array( $args['resources'] ) ) ? $args['resources'] : '';
				$arg_resource    = explode( ',', $_resources );
				$i               = 0;
				$newresourcedata = array();

				$filter = isset( $args['filter'] ) ? $args['filter'] : '';

				foreach ( $resources as $res => $resource ) {
					if ( in_array( $res, $arg_resource ) || 'resources' !== $filter ) {
						if ( $push ) { // date.
							$bookable_item['extendedProps']['resources'] = $res . '=>' . $resource;
							array_push( $events, $bookable_item );
							$resource_push = true;
						} else { // time.
							foreach ( $bookable_item as $b => $b_i ) {

								$consider = apply_filters( 'bkap_resource_event_based_on_availability_data', true, $res, $bookable->ID, $b_i );
								if ( $consider ) {
									$newresourcedata[ $i ]                               = $b_i;
									$newresourcedata[ $i ]['extendedProps']['resources'] = $res . '=>' . $resource;
									array_push( $events, $newresourcedata[ $i ] );
									$resource_push = true;
									$i++;
								}
							}
						}
					}
				}
				if ( $resource_push ) {
					$push = false;
				}
			}

			// Handle variations for Products.
			if ( 'only_day' === $booking_type && 'variable' === $product_type ) {
				$product_variations = $_product->get_available_variations( 'object' );

				$titles = array();

				foreach ( $_product->get_attributes() as $product_attribute ) {
					$attribute_name           = $product_attribute->get_name();
					$attribute_key            = 'attribute_' . sanitize_title( $attribute_name );
					$titles[ $attribute_key ] = $attribute_name;
				}

				foreach ( $product_variations as $variation ) {
					$price          = $variation->get_price();
					$attributes     = $variation->get_variation_attributes();
					$variation_data = array();

					foreach ( $attributes as $title => $attribute ) {
						$unsanitized_title = $titles[ $title ];
						$variation_data[]  = array(
							'id'               => $variation->get_id(),
							'price'            => $price,
							$unsanitized_title => $attribute,
						);
					}

					if ( count( $variation_data ) > 0 ) {
						$bookable_item['extendedProps']['variation_data'] = $variation_data;
						array_push( $events, $bookable_item );
						$push = false;
					}
				}
			}

			// Add to collection array.
			if ( $push ) {
				array_push( $events, $bookable_item );
			}
		}

		// Availability.
		if ( ! in_array( $booking_type, array( 'duration_time' ) ) ) {

			$is_date_based = in_array( $booking_type, array( 'only_day', 'multiple_days', 'multidates' ) );
			$is_time_based = in_array( $booking_type, array( 'date_time', 'multidates_fixedtime' ) );

			foreach ( $events as &$event ) {

				$availability = array();

				// Get array of dates between start_date and end_date.
				$interval   = new DateInterval( 'P1D' );
				$date_start = new DateTime( $event['extendedProps']['start'] );
				$date_end   = new DateTime( $event['extendedProps']['end'] );
				$date_end->add( $interval );
				$period = new DatePeriod( $date_start, $interval, $date_end );

				foreach ( $period as $_date ) {

					$date  = $_date->format( 'Y-m-d' );
					$date_ = $_date->format( 'j-n-Y' );
					$post  = array(
						'post_id'      => (int) $event['id'],
						'date'         => $date,
						'checkin_date' => $date,
						'bkap_page'    => 'product',
						'cal_price'    => true,
					);

					// Resources.
					if ( isset( $event['extendedProps']['resources'] ) && '' !== $event['extendedProps']['resources'] ) {
						$exp                 = explode( '=>', $event['extendedProps']['resources'] );
						$post['resource_id'] = $exp[0];
					}

					// Variation.
					if ( isset( $event['extendedProps']['variation_data'] ) && '' !== $event['extendedProps']['variation_data'] && is_array( $event['extendedProps']['variation_data'] ) ) {
						$post['variation_id'] = $event['extendedProps']['variation_data'][0]['id'];
					}

					if ( $is_date_based ) {
						$availability[ $date_ ] = bkap_booking_process::bkap_date_lockout( $post );
					} elseif ( $is_time_based ) {
						$post['timeslot_value'] = ( isset( $event['extendedProps'] ) && isset( $event['extendedProps']['timeslot_value'] ) ) ? $event['extendedProps']['timeslot_value'] : '';
						$post['date_time_type'] = 'on';
						$availability[ $date_ ] = bkap_booking_process::bkap_get_time_lockout( $post );
					}
				}

				$event['extendedProps']['availability_data'] = $availability;
			}
		}

		// For issue 5026.
		if ( count( $last_event_date ) > 0 ) {
			$l_event_date = max( $last_event_date );
			$events       = array_map(
				function( $arr ) use ( $l_event_date ) {
					return $arr + array( 'last_event_date' => $l_event_date );
				},
				$events
			);
		}

		return $events;
	}

    // ----------------------------------------------------
    // تابع کاستوم برای گرفتن تاریخ‌های موجود (که در لاگ خطا بود)
    // ----------------------------------------------------
    public static function get_available_dates( $product_id ) {
        $booking_settings = get_post_meta( $product_id, 'woocommerce_booking_settings', true );
        $available_dates = array();

        if ( isset($booking_settings['booking_time_settings']) && is_array($booking_settings['booking_time_settings']) ) {
            foreach ( $booking_settings['booking_time_settings'] as $weekday => $slots ) {
                if ( ! empty($slots) ) {
                    for ( $i = 0; $i < 30; $i++ ) {
                        $date = strtotime("+$i day");
                        $weekday_name = self::weekday_key_to_name( $weekday );
                        if ( strtolower(date('l', $date)) === $weekday_name ) {
                            $available_dates[] = date('Y-m-d', $date);
                        }
                    }
                }
            }
        }

        return array_unique($available_dates);
    }

    private static function weekday_key_to_name( $key ) {
        $map = array(
            'booking_weekday_0' => 'sunday',
            'booking_weekday_1' => 'monday',
            'booking_weekday_2' => 'tuesday',
            'booking_weekday_3' => 'wednesday',
            'booking_weekday_4' => 'thursday',
            'booking_weekday_5' => 'friday',
            'booking_weekday_6' => 'saturday',
        );
        return isset($map[$key]) ? $map[$key] : '';
    }
}
// ----------------------------------------------------

// اضافه کردن available_dates و پارامترهای AJAX به جاوااسکریپت
add_action( 'wp_enqueue_scripts', function() {
    global $post;
    if ( is_product() && isset($post->ID) ) {
        $available_dates = BKAP_Bookable_Query::get_available_dates( $post->ID );
        wp_localize_script( 'jquery-ui-datepicker', 'bkap_available_dates', $available_dates );

        // برای AJAX
        wp_localize_script( 'jquery-ui-datepicker', 'bkap_frontend_params', array(
            'ajax_url'   => admin_url( 'admin-ajax.php' ),
            'product_id' => $post->ID,
        ));
    }
});

// AJAX برای گرفتن تایم‌اسلات و میزها (تابع مورد نیاز شما)
add_action( 'wp_ajax_bkap_get_time_slots', 'bkap_get_time_slots' );
add_action( 'wp_ajax_nopriv_bkap_get_time_slots', 'bkap_get_time_slots' );

function bkap_get_time_slots() {
    $date = sanitize_text_field($_POST['date']);
    $product_id = intval($_POST['product_id']);

    $booking_settings = get_post_meta( $product_id, 'woocommerce_booking_settings', true );
    $weekday = 'booking_weekday_' . strtolower(date('w', strtotime($date)));

    $slots = isset($booking_settings['booking_time_settings'][$weekday]) ? $booking_settings['booking_time_settings'][$weekday] : array();


    if ( ! empty($slots) ) {
        // فیلدهای مورد استفاده در JS: فیلد زمان پلاگین و دو فیلد کاستوم ما
        printf( '<input type="hidden" name="bkap_selected_timeslot" id="bkap_selected_timeslot" value="" required />' );
        printf( '<input type="hidden" name="bkap_table_name" id="bkap_table_name" value="" />' );
        printf( '<input type="hidden" name="time_slot" id="time_slot" value="" />' );
        

        echo "<div style='color:red;font-weight:bold; margin-top: 10px;'>لطفاً تایم اسلات و سپس میز خود را انتخاب کنید:</div>";

        foreach ( $slots as $slot_key => $slot ) {
            $timeslot_display = $slot['from_slot_hrs'] . ":" . $slot['from_slot_min'] . " - " . $slot['to_slot_hrs'] . ":" . $slot['to_slot_min'];
            $unique_slot_id   = 'slot_' . md5($timeslot_display . $slot_key);
            
            echo "<div class='bkap-time-slot-container' style='border: 1px solid #ccc; padding: 10px; margin-bottom: 10px;'>";
            
            // 1. دکمه رادیویی برای انتخاب تایم‌اسلات
            printf(
                '<label style="display: block; font-size: 1.1em; font-weight: bold;">
                    <input type="radio" name="bkap_slot_selection" 
                           class="bkap_slot_radio"
                           value="%s" 
                           data-target="#%s"
                           />
                    🕒 زمان: %s
                </label><br/>',
                esc_attr( $timeslot_display ), 
                esc_attr( $unique_slot_id ),
                esc_html( $timeslot_display )
            );

            // 2. کانتینر میزها (در ابتدا پنهان است)
            echo "<div id='" . esc_attr($unique_slot_id) . "' class='bkap-tables-selection' style='padding-right: 20px; display: none;'>";
            echo "<strong>میزهای موجود:</strong><br/>";
            
            if ( ! empty($slot['tables']) ) {
                foreach ( $slot['tables'] as $table_key => $table ) {
                    $table_value = $timeslot_display . "|" . $table['name']; 
                    
                    printf(
                        '<label class="bkap-table-option" style="display: block; margin-left: 10px;">
                            <input type="radio" name="bkap_table_for_slot_%s" 
                                   class="bkap_table_radio"
                                   data-time-slot="%s" 
                                   value="%s" 
                                   data-table-name="%s"
                                   required 
                                   />
                            %s (تعداد موجود: %s)
                        </label>',
                        esc_attr( $unique_slot_id ), 
                        esc_attr( $timeslot_display ),
                        esc_attr( $table_value ),
                        esc_attr( $table['name'] ),
                        esc_html( $table['name'] ),
                        esc_html( $table['qty'] )
                    );
                }
            } else {
                echo "<p style='color: red;'>میزی برای این تایم‌اسلات تعریف نشده است.</p>";
            }
            
            echo "</div>"; // پایان کانتینر میزها
            echo "</div>"; // پایان کانتینر اصلی تایم‌اسلات
        }
    } else {
        echo "<p>No time slots available for this date.</p>";
    }

    wp_die();
}


/**
 * 1. ذخیره داده‌های کاستوم در آیتم سبد خرید (PHP HOOK)
 */
function bkap_add_custom_booking_data_to_cart( $cart_item_data, $product_id, $variation_id ) {
    
    if ( isset( $_POST['booking_calender'] ) && isset( $_POST['bkap_selected_timeslot'] ) ) {
        
        $selected_date      = sanitize_text_field( $_POST['booking_calender'] );
        $selected_slot_data = sanitize_text_field( $_POST['bkap_selected_timeslot'] );
        
        if ( empty( $selected_slot_data ) || empty( $selected_date ) ) {
            return $cart_item_data; 
        }
        
        list( $time_slot, $table_name ) = explode( '|', $selected_slot_data );

        // **حذف هرگونه Resource ID در سطح POST برای جلوگیری از اعتبارسنجی BKAP**
        if ( isset( $_POST['bkap_resource_id'] ) ) {
             unset( $_POST['bkap_resource_id'] );
        }
        if ( isset( $_POST['resource_id'] ) ) { 
             unset( $_POST['resource_id'] );
        }
        if ( isset( $_POST['wapbk_resource_selection'] ) ) {
            unset( $_POST['wapbk_resource_selection'] );
        }

        // داده‌های سفارشی را به آرایه cart_item_data اضافه کن
        $cart_item_data['bkap_custom_booking'] = true;
        $cart_item_data['bkap_date'] = $selected_date;
        $cart_item_data['bkap_time_slot'] = sanitize_text_field( $time_slot );
        $cart_item_data['bkap_table_name'] = sanitize_text_field( $table_name );
        
        $cart_item_data['unique_key'] = md5( $selected_slot_data . $selected_date . microtime() );
    }

    return $cart_item_data;
}
add_filter( 'woocommerce_add_cart_item_data', 'bkap_add_custom_booking_data_to_cart', 10, 3 );


/**
 * 2. نمایش داده‌های کاستوم در سبد خرید و تسویه حساب
 */
function bkap_display_custom_booking_data_in_cart( $item_data, $cart_item ) {
    if ( isset( $cart_item['bkap_custom_booking'] ) && true === $cart_item['bkap_custom_booking'] ) {
        if ( ! empty( $cart_item['bkap_date'] ) ) {
            $item_data[] = array(
                'key'     => __( 'Booking Date', 'textdomain' ),
                'value'   => $cart_item['bkap_date'],
                'display' => '',
            );
        }
        if ( ! empty( $cart_item['bkap_time_slot'] ) ) {
            $item_data[] = array(
                'key'     => __( 'Time Slot', 'textdomain' ),
                'value'   => $cart_item['bkap_time_slot'],
                'display' => '',
            );
        }
        if ( ! empty( $cart_item['bkap_table_name'] ) ) {
            $item_data[] = array(
                'key'     => __( 'Table Name', 'textdomain' ),
                'value'   => $cart_item['bkap_table_name'],
                'display' => '',
            );
        }
    }
    return $item_data;
}
add_filter( 'woocommerce_get_item_data', 'bkap_display_custom_booking_data_in_cart', 10, 2 );
<?php
/**
 * It will Add all the Boilerplate component when we activate the plugin.
 *
 * @author  Tyche Softwares
 * @package BKAP/Admin/Component
 */

 defined( 'ABSPATH' ) || exit;

/**
 * It will Add all the Boilerplate component when we activate the plugin.
 */
class BKAP_Admin_Component {

	/**
	 * It will Add all the Boilerplate component when we activate the plugin.
	 */
	public function __construct() {

		if ( ! is_admin() ) {
			return;
		}

		BKAP_Files::include_file( BKAP_PLUGIN_PATH . '/includes/admin/component/license-active-notice/ts-active-license-notice.php' );
		BKAP_Files::include_file( BKAP_PLUGIN_PATH . '/includes/admin/component/plugin-tracking/class-tyche-plugin-tracking.php' );
		BKAP_Files::include_file( BKAP_PLUGIN_PATH . '/includes/admin/component/plugin-deactivation/class-tyche-plugin-deactivation.php' );

		$bkap_plugin_name   = EDD_SL_ITEM_NAME_BOOK;
		$bkap_locale        = 'woocommerce-booking';
		$bkap_file_name     = 'woocommerce-booking/woocommerce-booking.php';
		$bkap_plugin_prefix = 'bkap';

		add_filter( 'ts_tracker_data', array( 'bkap_common', 'bkap_ts_add_plugin_tracking_data' ), 10, 1 );
		add_action( 'admin_footer', array( __CLASS__, 'ts_admin_notices_scripts' ) );
		add_action( 'admin_init', array( __CLASS__, 'ts_reset_tracking_setting' ) );
		add_action( $bkap_plugin_prefix . '_init_tracker_completed', array( __CLASS__, 'init_tracker_completed' ), 10, 2 );

		new Tyche_Plugin_Tracking(
			array(
				'plugin_name'       => $bkap_plugin_name,
				'plugin_locale'     => $bkap_locale,
				'plugin_short_name' => $bkap_plugin_prefix,
				'version'           => BKAP_VERSION,
				'blog_link'         => 'https://www.tychesoftwares.com/booking-appointment-plugin-usage-tracking',
			)
		);

		new Bkap_Active_License_Notice( $bkap_plugin_name, 'edd_sample_license_status', 'admin.php?page=bkap_page#/license', $bkap_locale );

		new Tyche_Plugin_Deactivation(
			array(
				'plugin_name'       => $bkap_plugin_name,
				'plugin_base'       => $bkap_file_name,
				'script_file'       => BKAP_Files::rewrite_asset_url( '/assets/js/plugin-deactivation.js', BKAP_FILE ),
				'plugin_short_name' => $bkap_plugin_prefix,
				'version'           => BKAP_VERSION,
			)
		);
	}

	/**
	 * Load the js file in the admin
	 *
	 * @since 6.8
	 * @access public
	 */
	public static function ts_admin_notices_scripts() {
		wp_enqueue_script(
			'bkap_ts_dismiss_notice',
			BKAP_Files::rewrite_asset_url( '/assets/js/dismiss-tracking-notice.js', BKAP_FILE ),
			array(),
			BKAP_VERSION,
			false
		);

		wp_localize_script(
			'bkap_ts_dismiss_notice',
			'bkap_ts_dismiss_notice',
			array(
				'ts_prefix_of_plugin' => 'bkap',
				'ts_admin_url'        => admin_url( 'admin-ajax.php' ),
			)
		);
	}

	/**
	 * It will delete the tracking option from the database.
	 */
	public static function ts_reset_tracking_setting() {
		if ( isset( $_GET ['ts_action'] ) && 'reset_tracking' == $_GET ['ts_action'] ) { // phpcs:disable WordPress.Security.NonceVerification
			Tyche_Plugin_Tracking::reset_tracker_setting( 'bkap' );
			$ts_url = remove_query_arg( 'ts_action' );
			wp_safe_redirect( $ts_url );
		}
	}

	/**
	 * Redirects after initializing the tracker.
	 */
	public static function init_tracker_completed() {
		header( 'Location: ' . admin_url( 'admin.php?page=bkap_page&action=settings#/' ) );
		exit;
	}
}

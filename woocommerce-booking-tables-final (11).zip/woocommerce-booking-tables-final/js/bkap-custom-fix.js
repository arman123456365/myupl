jQuery(function ($) {
  console.log("BKAP CUSTOM FIX: loaded inline v4");

  // --------------------------
  // Timeslot radios
  // --------------------------
  $(document).off('change', '.bkap_slot_radio').on('change', '.bkap_slot_radio', function(){
    var timeVal = $(this).val();
    $("input#time_slot").last().val(timeVal).trigger('change');
    console.log("BKAP CUSTOM FIX: slot change ->", timeVal);
  });

  // --------------------------
  // Table radios
  // --------------------------
  $(document).off('change click', '.bkap_table_radio').on('change click', '.bkap_table_radio', function(){
    var $t = $(this);
    var timeOnly = $t.data('time-slot') || $('.bkap_slot_radio:checked').val() || ($t.val() ? $t.val().split('|')[0] : '');
    var tableName = $t.data('table-name') || ($t.val() ? ($t.val().split('|')[1] || $t.val()) : '');
    var full = (timeOnly ? timeOnly : '') + '|' + (tableName ? tableName : '');

    $("input#time_slot").last().val(timeOnly).trigger('change');
    $('#bkap_selected_timeslot').val(full);
    $('#bkap_table_name').val(tableName);

    console.log("BKAP CUSTOM FIX: table click ->", timeOnly, tableName, full);
  });

  // --------------------------
  // Book Now button → Submit Woo form
  // --------------------------
  $(document).off('click', '.single_add_to_cart_button').on('click', '.single_add_to_cart_button', function(e){
    e.preventDefault();

    // گرفتن مقادیر قبل از ارسال
    var ts = $("input#time_slot").last().val();
    var st = $('#bkap_selected_timeslot').val();
    var tn = $('#bkap_table_name').val();

    console.log("BKAP JS: Submitting form directly.");
    console.log("➡ time_slot:", ts);
    console.log("➡ bkap_selected_timeslot:", st);
    console.log("➡ table_name:", tn);

    var $form = $(this).closest('form.cart');
    if ($form.length) {
      $form.submit();
    } else {
      console.error("BKAP JS: Cart form not found!");
    }
  });
});

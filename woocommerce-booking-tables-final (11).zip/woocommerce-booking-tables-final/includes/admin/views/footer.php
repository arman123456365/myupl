<?php
/**
 * Bookings and Appointment Plugin for WooCommerce.
 *
 * Admin Footer.
 *
 * @author      Tyche Softwares
 * @package     BKAP/Admin/Views
 * @since       5.19.0
 */
?>

<div class="bkap-footer">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="footer-wrap">
						<div class="ft-text">
							<p>
								<a href="<?php echo esc_url( 'https://support.tychesoftwares.com/help/2285384554?utm_source=bkapfooter&utm_medium=link&utm_campaign=BookingAndAppointmentPlugin' ); ?>" target="_blank">
									<?php echo esc_html__( 'Need Support?', 'woocommerce-booking' ); ?>
								</a> 
								<strong><?php echo esc_html__( 'We’re always happy to help you.', 'woocommerce-booking' ); ?></strong>
							</p>
							<p>
								<?php
								printf(
									/* translators: %s Link to rate it */
									esc_html__(
										'If this plugin helped you, %1$s %2$s',
										'woocommerce-booking'
									),
									sprintf(
										/* Translators: %s Link, %s Link Name */
										'<a href="%s" target="_blank" rel="noopener noreferrer">%s</a>',
										esc_url( 'https://www.tychesoftwares.com/submit-review/?utm_source=bkapfooter&utm_medium=link&utm_campaign=BookingAndAppointmentPlugin' ),
										esc_html__( 'please rate it', 'woocommerce-booking' )
									),
									sprintf( '<span class="rating">★★★★★</span>' )
								);
								?>
							</p>
						</div>
						</div>
					</div>
				</div>
			</div>
		</div>
</div>

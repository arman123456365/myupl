<template id="booking-metabox-template">
	<section>
		<div class="bd-page-wrap">
			<div class="row mr-0 ml-0">
				<div class="col-md-12 pr-0 pl-0">
					<div class="wbc-box no-background">
						<div class="wbc-content pt-0">
							<div class="tbl-mod-1">
								<div class="tm1-row border-bottom">
									<div class="col-left"></div>
									<div class="col-right d-flex justify-content-between align-items-center">
										<div class="left-checkbox d-flex"></div>
										<div class="copy-btn">
											<span>
												<svg width="16" height="16" viewBox="0 0 18 21" fill="none"
													xmlns="http://www.w3.org/2000/svg">
													<path
														d="M1.12003 16.8636H3.8473V19.5909C3.8473 20.093 4.25433 20.5 4.75639 20.5H16.8776C17.3797 20.5 17.7867 20.093 17.7867 19.5909V5.04545C17.7867 4.54339 17.3797 4.13636 16.8776 4.13636H14.1503V1.40909C14.1503 0.90703 13.7433 0.5 13.2412 0.5H1.12003C0.617968 0.5 0.210938 0.90703 0.210938 1.40909V15.9545C0.210938 16.4566 0.617968 16.8636 1.12003 16.8636ZM15.9685 18.6818H5.66548V5.95455H15.9685V18.6818ZM2.02912 2.31818H12.3321V4.13636H4.75639C4.25433 4.13636 3.8473 4.54339 3.8473 5.04545V15.0455H2.02912V2.31818Z"
														fill="#A7ACB1"></path>
												</svg> <a href="javascript:void(0);"
													v-on:click.stop="data.fn.copy_booking_settings(data)"
													title="<?php esc_html_e( 'Click to copy the Booking Settings of this product. Note: This option is only for Debugging purpose. Before copying the settings, please make sure you have updated the product.', 'woocommerce-booking' ); ?>">
													Copy Booking Settings</a></span>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="wbc-content">
							<div class="tbl-mod-1">
								<div class="tm1-row p-0">
									<div class="col-left col-left-sidebar">
										<?php BKAP_Files::include_file( BKAP_PLUGIN_PATH . '/includes/admin/templates/metabox/booking/sidebar.php' ); ?>
									</div>
									<div class="col-right col-right-sidebar">
										<?php BKAP_Files::include_file( BKAP_PLUGIN_PATH . '/includes/admin/templates/metabox/booking/general.php' ); ?>
										<?php BKAP_Files::include_file( BKAP_PLUGIN_PATH . '/includes/admin/templates/metabox/booking/availability.php' ); ?>
										<?php BKAP_Files::include_file( BKAP_PLUGIN_PATH . '/includes/admin/templates/metabox/booking/integrations.php' ); ?>
										<?php BKAP_Files::include_file( BKAP_PLUGIN_PATH . '/includes/admin/templates/metabox/booking/block_pricing.php' ); ?>
										<?php BKAP_Files::include_file( BKAP_PLUGIN_PATH . '/includes/admin/templates/metabox/booking/resources.php' ); ?>
										<?php BKAP_Files::include_file( BKAP_PLUGIN_PATH . '/includes/admin/templates/metabox/booking/persons.php' ); ?>
										<?php BKAP_Files::include_file( BKAP_PLUGIN_PATH . '/includes/admin/templates/metabox/booking/rental.php' ); ?>
										<?php BKAP_Files::include_file( BKAP_PLUGIN_PATH . '/includes/admin/templates/metabox/booking/partial_payments.php' ); ?>
										<?php BKAP_Files::include_file( BKAP_PLUGIN_PATH . '/includes/admin/templates/metabox/booking/seasonal_pricing.php' ); ?>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
</template>

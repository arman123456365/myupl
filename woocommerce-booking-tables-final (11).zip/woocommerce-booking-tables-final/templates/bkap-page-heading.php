<?php
/**
 * Page Heading.
 *
 * @package BKAP/Vendor-Booking-Dashboard
 */

?>
<section class="heading">
	<div class="wrap">  
		<h1><b><?php echo esc_html( $bkap_heading ); ?></b></h1>
	</div>
</section>
<hr>
